﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Track_Maker
{
    public class Basin
    {
        public string Name { get; set; } // the name of the basin
        public BitmapImage BasinImage { get; set; } // the basin image name
        public string BasinImagePath { get; set; } // the basin image path. we only load what we need.
        public List<Storm> Storms { get; set; } // list of storms
        public Storm CurrentStorm { get; set; }

        public Basin()
        {
            Storms = new List<Storm>(); 
        }
    }
}
