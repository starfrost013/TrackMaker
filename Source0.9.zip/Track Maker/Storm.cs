﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Track_Maker
{
    public enum StormType { Tropical, Subtropical, Extratropical, InvestPTC, PolarLow }
    public class Storm
    {
        public DateTime FormationDate { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Node> NodeList { get; set; }
        public List<Node> NodeList_Deleted { get; set; } // nodes deleted using undo. 
        public StormType StormType { get; set; }

        public Storm()
        {
            NodeList = new List<Node>();
            NodeList_Deleted = new List<Node>(); 
        }

        public void Redo()
        {
            // restore the last node. 

            if (NodeList_Deleted.Count == 0) return; 

            Node Reincarnated = NodeList_Deleted[NodeList_Deleted.Count - 1];
            NodeList.Add(Reincarnated);
            NodeList_Deleted.Remove(Reincarnated); 
        }

        public void Undo()
        {
            // remove the last node

            if (NodeList.Count == 0) return; 

            Node Victim = NodeList[NodeList.Count - 1];
            NodeList_Deleted.Add(Victim);
            NodeList.Remove(Victim); 
        }
    }

}
