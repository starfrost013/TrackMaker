﻿using ACECalculator; // temp: integrate
using AdvisoryGenerator; // temp: integrate
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Track_Maker
{
    public partial class MainWindow : Window
    {

        /// <summary>
        /// MOVE THIS CODE
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BasinMenu_BasinSwitch_Click(object sender, RoutedEventArgs e)
        {
            BasinSwitcher BasinSwitch = new BasinSwitcher();
            BasinSwitch.Owner = this;
            BasinSwitch.Show();
        }

        private void BasinMenu_Clear_Click(object sender, RoutedEventArgs e)
        {
            CurrentBasin.CurrentStorm = null; 
            CurrentBasin.Storms.Clear();
        }

        private void ViewMenu_Names_Click(object sender, RoutedEventArgs e)
        {
            // Toggle name visibility. 
            switch (ViewMenu_Names.IsChecked)
            {
                case false:
                    Setting.DefaultVisibleTextNames = false;
                    return;
                case true:
                    Setting.DefaultVisibleTextNames = true;
                    return;
            }
           
        }

        private void Window_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {

            // if we have no storms, ask the user to create a storm instead of add a track point. 
            if (CurrentBasin.CurrentStorm == null)
            {
                AddNewStorm Addstwindow = new AddNewStorm();
                Addstwindow.Owner = this;
                Addstwindow.Show();
                return;
            }

            AddTrackPoint Addtrwindow = new AddTrackPoint(e.GetPosition(HurricaneBasin));
            Addtrwindow.Owner = this;
            Addtrwindow.Show();
        }

        private void EditMenu_Categories_Click(object sender, RoutedEventArgs e)
        {
            CategoryManagerWindow Catmanwindow = new CategoryManagerWindow();
            Catmanwindow.Owner = this;
            Catmanwindow.Show();
        }

        private void FileMenu_Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void HelpMenu_About_Click(object sender, RoutedEventArgs e)
        {
            AboutWindow AbtWin = new AboutWindow();
            AbtWin.Owner = this;
            AbtWin.Show();
        }

        private void EditMenu_Season_Click(object sender, RoutedEventArgs e)
        {
            SeasonManager SMan = new SeasonManager();
            SMan.Owner = this;
            SMan.Show();
        }

        private void FileMenu_SaveImage_Click(object sender, RoutedEventArgs e)
        {
            ExportUI ExportUI = new ExportUI(FormatType.Export, new ExportImage());
            ExportUI.Owner = this;
            ExportUI.Show(); 
        }

        private void FileMenu_LoadXML_Click(object sender, RoutedEventArgs e)
        {
            ExportUI ExportUI = new ExportUI(FormatType.Import, new ExportXML());
            ExportUI.Owner = this;
            ExportUI.Show(); 
        }

        private void FileMenu_SaveXML_Click(object sender, RoutedEventArgs e)
        {
            ExportUI ExportUI = new ExportUI(FormatType.Export, new ExportXML());
            ExportUI.Owner = this;
            ExportUI.Show();
        }

        private void ToolsMenu_ACECalculator_Click(object sender, RoutedEventArgs e)
        {
            CalcMainWindow Cmain = new CalcMainWindow();
            Cmain.Owner = this;
            Cmain.Show();
        }

        private void ToolsMenu_AdvisoryGenerator_Click(object sender, RoutedEventArgs e)
        {
            AdvMainWindow Amain = new AdvMainWindow();
            Amain.Owner = this;
            Amain.Show(); 
        }

        private void HelpMenu_Preferences_Click(object sender, RoutedEventArgs e)
        {
            Settings Settings = new Settings();
            Settings.Owner = this;
            Settings.Show(); 
        }

        private void StormMenu_AddNew_Click(object sender, RoutedEventArgs e)
        {
            Logging.Log("Creating new storm window...");
            AddNewStorm AddNewStorm = new AddNewStorm();
            AddNewStorm.Show();
        }
    }
}
